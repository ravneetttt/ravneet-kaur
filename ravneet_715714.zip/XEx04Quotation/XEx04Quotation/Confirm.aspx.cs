﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace XEx04Quotation
{
    public partial class Confirm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            lblSalesPrice.Text = Session["salesPrice"].ToString();
            lblDiscountAmount.Text = Session["discountAmount"].ToString();
            lblTotalPrice.Text = Session["TotalPrice"].ToString();

        }

        protected void Btn_sendQuotation_Click(object sender, EventArgs e)
        {
            if (txtEmail.Text == null || txtName.Text == null)
            {
                Label1.Text = "please enter the email and name";
            }
            else
            {
                Label1.Text = "Thank you for sending the Quotation !" +
                    "click the return to go back to home page";
            }
        }
    }
}